const fs = require("fs").promises;

async function run() {

    const feedback = "Node.js is awesome!";

    // write file
    await fs.writeFile("feedback.txt", feedback);

    console.log("Data written successfully.");

    console.log("Reading file...");

    // read file
    const data = await fs.readFile("feedback.txt", "utf8");

    console.log(data);
}

run();