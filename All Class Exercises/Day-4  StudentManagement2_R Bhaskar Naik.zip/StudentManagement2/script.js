/* LOGIN VALIDATION */
function login(){
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    if(user === "Harshi Bai" && pass === "Harshi@1234"){
        showSection("dashboardPage");
    } else{
        document.getElementById("error").innerText =
        "Invalid Username or Password";
    }
}

/* SECTION SWITCH */
function showSection(id){
    document.querySelectorAll(".section").forEach(sec=>{
        sec.classList.remove("active");
    });
    document.getElementById(id).classList.add("active");
}

/* TOGGLE STUDENT INFO */
function toggleInfo(){
    let info = document.getElementById("studentInfo");
    info.style.display = info.style.display === "block" ? "none" : "block";
}

/* OPEN CALENDAR */
function openCalendar(){
    showSection("calendarPage");
    generateCalendar();
}

/* BACK */
function backToDashboard(){
    showSection("dashboardPage");
}

/* EVENTS DATA */
let events = {
    5: "Maths Test",
    12: "Science Project Submission",
    18: "Parent Teacher Meeting",
    25: "Sports Practice"
};

/*CALENDAR */
function generateCalendar(){
    let calendar = document.getElementById("calendar");
    calendar.innerHTML = "";

    for(let i=1;i<=30;i++){
        let day = document.createElement("div");
        day.classList.add("day");
        day.innerText = i;

        if(events[i]){
            day.classList.add("event-day");
        }

        day.onclick = function(){
            if(events[i]){
                let box = document.getElementById("eventBox");
                box.style.display = "block";
                box.innerHTML =
                    "<strong>Date:</strong> " + i +
                    "<br><strong>Event:</strong> " + events[i];
            }
        };

        calendar.appendChild(day);
    }
}
