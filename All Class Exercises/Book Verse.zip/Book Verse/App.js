import logo from './logo.svg';
import './App.css';
import BookList from './components/BookList';

function App() {
  return (
    <div>
      <h1>BookVerse</h1>
      <p>Welcome Page and Featured Books Section</p>
      <BookList />
    </div>
  );
}

export default App;
