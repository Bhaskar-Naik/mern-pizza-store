import React from "react";

const BookCard = ({ book, viewMode }) => {
  return (
    <div
      style={{
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "15px",
        display: viewMode === "list" ? "flex" : "block",
        gap: "15px",
        marginBottom: viewMode === "list" ? "15px" : "0"
      }}
    >
      <img
        src={book.image}
        alt={book.title}
        style={{
          width: viewMode === "list" ? "100px" : "80%",
          height: viewMode === "list" ? "120px" : "200px",
          objectFit: "cover",
          borderRadius: "6px"
        }}
      />

      <div>
        <h3>{book.title}</h3>
        <p>Author: {book.author}</p>
        <p>Price: ${book.price}</p>
      </div>
    </div>
  );
};

export default BookCard;