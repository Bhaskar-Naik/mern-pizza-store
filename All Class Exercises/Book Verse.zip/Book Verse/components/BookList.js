import React, { useState } from "react";
import BookCard from "./BookCard";

const BookList = () => {
  const [viewMode, setViewMode] = useState("grid");
  const [searchTerm, setSearchTerm] = useState("");

  const books = [
    {
      title: "Ikigai",
      author: "Héctor García & Francesc Miralles",
      price: 998.9,
      image: "https://m.media-amazon.com/images/I/81l3rZK4lnL._SY425_.jpg"
    },
    {
      title: "The Power of Subconscious Mind",
      author: "Dr. Joseph Murphy",
      price: 8.99,
      image: "https://m.media-amazon.com/images/I/81ZPvRTVBwL._AC_UF1000,1000_QL80_.jpg"
    },
    {
      title: "The Missile Man of India",
      author: "A.P.J. Abdul Kalam",
      price: 100.89,
      image: "https://m.media-amazon.com/images/I/81+Vf3lmPJL._UF1000,1000_QL80_.jpg"
    }
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div style={{ padding: "20px" }}>

      {/* Top Controls */}
      <div style={{ marginBottom: "20px", display: "flex", gap: "10px" }}>
        
        <input
          type="text"
          placeholder="Search books..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{ padding: "8px", width: "200px" }}
        />

        <button onClick={() => setViewMode("grid")}>
          Grid
        </button>

        <button onClick={() => setViewMode("list")}>
          List
        </button>

      </div>

      {/* Books Container */}
      <div
        style={{
          display: viewMode === "grid" ? "grid" : "block",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: "20px"
        }}
      >
        {filteredBooks.map((book, index) => (
          <BookCard key={index} book={book} viewMode={viewMode} />
        ))}
      </div>

    </div>
  );
};

export default BookList;