function validateCourseId(req, res, next) {

    const id = req.params.id;
    // Check if ID is numeric
    if (isNaN(id)) {
        return res.status(400).json({
            error: "Invalid course ID"
        });
    }
    // Continue to next function
    next();
}

module.exports = validateCourseId;