const express = require("express");

const app = express();

const PORT = 4000;

// Import course routes
const courseRouter = require("./routes/courses");

// Root route
app.get("/", (req, res) => {

    res.send("Welcome to SkillSphere LMS API");

});

// Attach courses router
app.use("/courses", courseRouter);

app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});