const fs = require("fs");

fs.readFile("data.txt", "utf8", (err, data) => {

    if (err) {
        console.log(err);
        return;
    }

    console.log(data);

    setTimeout(() => {
        console.log("Read operation completed");
    }, 2000);

});