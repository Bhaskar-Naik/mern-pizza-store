const express = require("express");
const multer = require("multer");
const path = require("path");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage: storage });

app.post("/upload", upload.single("file"), (req, res) => {
  if (!req.file) {
    return res.status(400).send("No file uploaded");
  }

  res.send(`File uploaded successfully: ${req.file.originalname}`);
});

app.use("/materials", express.static(path.join(__dirname, "uploads")));

app.use(express.static("public"));

io.on("connection", (socket) => {

  console.log("User connected");

  socket.on("chat message", (msg) => {
    io.emit("chat message", msg);
  });

});

server.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});