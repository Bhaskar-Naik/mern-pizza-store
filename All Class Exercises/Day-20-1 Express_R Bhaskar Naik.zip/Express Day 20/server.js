const express = require("express");

const app = express();

const PORT = 4000;


// middleware
app.use(express.json());


// import router
const bookRouter = require("./routes/books");


// attach routes
app.use("/books", bookRouter);


// home route
app.get("/", (req,res)=>{
    res.send("Welcome to Express Server");
});


// 404 handler
app.use((req,res)=>{
    res.status(404).json({
        error:"Route not found"
    });
});


// global error handler
app.use((err,req,res,next)=>{

    console.error(err.stack);

    res.status(500).json({
        error:"Internal Server Error"
    });

});


app.listen(PORT, ()=>{
    console.log(`Server running at http://localhost:${PORT}`);
});