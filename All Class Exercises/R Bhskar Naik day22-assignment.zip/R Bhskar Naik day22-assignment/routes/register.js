const express = require("express");
const router = express.Router();
const bcrypt = require("bcrypt");

const passport = require("../config/passport");
const User = require("../models/User");

router.get("/", (req, res) => {
    res.render("register");
});

router.post("/register", async (req, res) => {

    const { firstName, lastName, email, phone, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({
        firstName,
        lastName,
        email,
        phone,
        password: hashedPassword
    });

    await newUser.save();
    console.log("User saved successfully");
    res.send(`Registration successful for ${firstName} ${lastName}`);
});

router.get("/login", (req, res) => {
    res.render("login");
});

router.post("/login", (req, res, next) => {

    passport.authenticate("local", (err, user, info) => {

        if (err) {
            return next(err);
        }

        if (!user) {
            return res.send("Access Denied");
        }

        req.logIn(user, function(err) {
            if (err) {
                return next(err);
            }

            return res.redirect("/admin");
        });

    })(req, res, next);

});

function isAdmin(req, res, next) {

    if (req.isAuthenticated() && req.user.role === "admin") {
        return next();
    }

    res.send("Access Denied");
}

router.get("/admin", isAdmin, (req, res) => {
    res.send("Welcome, Admin!");
});

module.exports = router;