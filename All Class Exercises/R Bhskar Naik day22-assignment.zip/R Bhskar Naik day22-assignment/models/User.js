const mongoose = require("../config/db");

const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    email: String,
    phone: String,
    password: String,
    role: {
        type: String,
        default: "user"
    }
});

module.exports = mongoose.model("User", userSchema);