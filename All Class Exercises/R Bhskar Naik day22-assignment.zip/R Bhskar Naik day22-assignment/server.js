const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");

require("./config/db");

const passport = require("./config/passport");

const registerRoute = require("./routes/register");

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(session({
    secret: "mysecretkey",
    resave: false,
    saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

app.use("/", registerRoute);

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});