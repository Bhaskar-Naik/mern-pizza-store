const express = require("express");
const rateLimit = require("express-rate-limit");

const courseRoutes = require("./routes/courses");

const app = express();

app.use(express.json());

const limiter = rateLimit({
    windowMs: 60 * 1000,
    max: 5,
    message: {
        error: "Too many requests",
        message: "Try again after 1 minute"
    }
});

app.use("/api/courses", limiter, courseRoutes);

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});