const express = require("express");
const { body, validationResult } = require("express-validator");

const router = express.Router();

let courses = [
    { id: 1, name: "NodeJS", duration: "3 months" },
    { id: 2, name: "Python", duration: "2 months" }
];

router.get("/", (req, res) => {
    res.json(courses);
});

router.post(
    "/",
    [
        body("name").notEmpty().withMessage("Course name is required"),
        body("duration").notEmpty().withMessage("Duration is required")
    ],
    (req, res) => {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ error: errors.array()[0].msg });
        }

        const { name, duration } = req.body;
        const newCourse = {
            id: courses.length + 1,
            name,
            duration
        };

        courses.push(newCourse);
        res.json(newCourse);
    }
);

router.put("/:id", (req, res) => {

    const id = parseInt(req.params.id);
    const course = courses.find(c => c.id === id);
    if (!course) {
        return res.status(404).json({ error: "Course not found" });
    }

    course.name = req.body.name || course.name;
    course.duration = req.body.duration || course.duration;
    res.json(course);
});

router.delete("/:id", (req, res) => {
    const id = parseInt(req.params.id);
    courses = courses.filter(c => c.id !== id);
    res.json({ message: "Course deleted" });
});

module.exports = router;