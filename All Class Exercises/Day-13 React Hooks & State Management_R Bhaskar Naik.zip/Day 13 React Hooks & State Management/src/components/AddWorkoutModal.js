import React, { useState } from "react";

const AddWorkoutModal = ({ addWorkout, close }) => {
  const [name, setName] = useState("");
  const [sets, setSets] = useState(3);
  const [rest, setRest] = useState(60);

  const handleSubmit = (e) => {
    e.preventDefault();
    addWorkout({ name, sets: Number(sets), rest: Number(rest) });
    close();
  };

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Add New Workout</h2>
        <form onSubmit={handleSubmit}>
          <label>Exercise Name</label>
          <input
            placeholder="e.g., Push-ups, Squats"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />

          <label>Target Sets</label>
          <input
            type="number"
            value={sets}
            onChange={(e) => setSets(e.target.value)}
          />

          <label>Rest Time (seconds)</label>
          <input
            type="number"
            value={rest}
            onChange={(e) => setRest(e.target.value)}
          />

          <div className="modal-buttons">
            <button type="submit" className="add-btn">
              Add Workout
            </button>
            <button type="button" className="cancel-btn" onClick={close}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddWorkoutModal;