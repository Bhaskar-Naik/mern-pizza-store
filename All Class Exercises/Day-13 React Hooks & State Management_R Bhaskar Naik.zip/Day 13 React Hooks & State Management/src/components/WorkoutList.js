import React from "react";

const WorkoutList = ({ workouts, deleteWorkout, startWorkout }) => {
  return (
    <div className="list">
      {workouts.map((workout) => (
        <div key={workout.id} className="card">
          <h3>{workout.name}</h3>
          <p>{workout.sets} Sets</p>

          <div className="card-buttons">
            <button
              className="start-btn"
              onClick={() => startWorkout(workout)}
            >
              Start
            </button>

            <button
              className="delete-btn"
              onClick={() => deleteWorkout(workout.id)}
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};

export default WorkoutList;