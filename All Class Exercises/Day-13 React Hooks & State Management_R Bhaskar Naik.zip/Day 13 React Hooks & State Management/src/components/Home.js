export default function Home({ openModal }) {
  return (
    <div className="home">
      <h2>Workout Tracker</h2>
      <p>Track your fitness journey</p>

      <button className="primary-btn" onClick={openModal}>
        Add Workout
      </button>

      <div className="empty-msg">
        No workouts yet. Add your first workout to get started!
      </div>
    </div>
  );
}