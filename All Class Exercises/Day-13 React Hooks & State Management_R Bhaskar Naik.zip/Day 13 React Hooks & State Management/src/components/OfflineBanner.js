import { useEffect, useState } from "react";

export default function OfflineBanner() {
  const [offline, setOffline] = useState(!navigator.onLine);

  useEffect(() => {
    window.addEventListener("offline", () => setOffline(true));
    window.addEventListener("online", () => setOffline(false));
  }, []);

  return offline ? <div className="offline">You are Offline</div> : null;
}