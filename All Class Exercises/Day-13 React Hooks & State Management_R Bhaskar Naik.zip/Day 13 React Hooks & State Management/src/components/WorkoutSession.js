import React, { useEffect, useState } from "react";

const WorkoutSession = ({ workout, goBack, updateWorkout }) => {
  const [time, setTime] = useState(0);
  const [running, setRunning] = useState(false);
  const [currentSet, setCurrentSet] = useState(1);

  useEffect(() => {
    let interval;
    if (running && time < workout.rest) {
      interval = setInterval(() => {
        setTime((prev) => prev + 1);
      }, 1000);
    }
    if (time >= workout.rest) {
      setRunning(false);
    }
    return () => clearInterval(interval);
  }, [running, time, workout.rest]);

  const format = (s) =>
    `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(
      s % 60
    ).padStart(2, "0")}`;

  const completeSet = () => {
    if (currentSet < workout.sets) {
      setCurrentSet(currentSet + 1);
      setTime(0);
    } else {
      updateWorkout(workout.id, workout.sets);
      goBack();
    }
  };

  return (
  <div className="session-container">

    <button className="back-btn" onClick={goBack}>
      ← Back to workouts
    </button>

    <div className="session-card">
      <h2 className="exercise-title">{workout.name}</h2>

      <p className="set-text">
        Set {currentSet} of {workout.sets}
      </p>

      <div className="timer-circle">
        {format(time)}
      </div>

      <p className="timer-label">Workout Time</p>

      <div className="session-buttons">
        <button className="start-btn" onClick={() => setRunning(true)}>Start</button>
        <button className="pause-btn" onClick={() => setRunning(false)}>Pause</button>
        <button
          className="reset-btn"
          onClick={() => {
            setTime(0);
            setRunning(false);
          }}
        >
          Reset
        </button>
      </div>

      <button className="complete-btn" onClick={completeSet}>
        Complete Set
      </button>
    </div>
  </div>
);};

export default WorkoutSession;