import { createSlice } from "@reduxjs/toolkit";

const workoutSlice = createSlice({
  name: "workouts",
  initialState: {
    items: []
  },
  reducers: {
    addWorkout: (state, action) => {
      state.items.push(action.payload);
    }
  }
});

export const { addWorkout } = workoutSlice.actions;
export default workoutSlice.reducer;