import React, { useState, useEffect } from "react";
import AddWorkoutModal from "./components/AddWorkoutModal";
import WorkoutList from "./components/WorkoutList";
import WorkoutSession from "./components/WorkoutSession";

function App() {
  const [workouts, setWorkouts] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [activeWorkout, setActiveWorkout] = useState(null);
  const [darkMode, setDarkMode] = useState(false);

  // PWA Install States
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [showInstall, setShowInstall] = useState(false);

  // Capture install event
  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstall(true);
    };

    window.addEventListener("beforeinstallprompt", handler);

    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  // Install button click
  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    await deferredPrompt.userChoice;

    setDeferredPrompt(null);
    setShowInstall(false);
  };

  // Add Workout
  const addWorkout = (workout) => {
    setWorkouts([
      ...workouts,
      {
        ...workout,
        id: Date.now(),
        completed: 0,
      },
    ]);
  };

  // Delete Workout
  const deleteWorkout = (id) => {
    setWorkouts(workouts.filter((w) => w.id !== id));
  };

  // Update Completed Sets
  const updateWorkout = (id, completedSets) => {
    setWorkouts(
      workouts.map((w) =>
        w.id === id ? { ...w, completed: completedSets } : w
      )
    );
  };

  return (
    <div className={`app ${darkMode ? "dark" : ""}`}>

      {/* HERO SECTION */}
      <section className="hero">
        <div className="hero-top">
          <div className="hero-left">
            <h1>Workout Tracker</h1>
            <p>Track your fitness journey</p>
          </div>

          <div className="hero-right">
            <button className="hero-link">Home</button>
            <button className="hero-link">About Us</button>

            <button
              className="theme-toggle"
              onClick={() => setDarkMode(!darkMode)}
            >
              {darkMode ? "☀" : "🌙"}
            </button>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT */}
      <div className="main-content">
        {!activeWorkout && (
          <>
            <button
              className="main-btn"
              onClick={() => setShowModal(true)}
            >
              Add Workout
            </button>

            {workouts.length === 0 ? (
              <p className="empty">
                No workouts yet. Add your first workout to get started!
              </p>
            ) : (
              <WorkoutList
                workouts={workouts}
                deleteWorkout={deleteWorkout}
                startWorkout={setActiveWorkout}
              />
            )}
          </>
        )}

        {showModal && (
          <AddWorkoutModal
            addWorkout={addWorkout}
            close={() => setShowModal(false)}
          />
        )}

        {activeWorkout && (
          <WorkoutSession
            workout={activeWorkout}
            goBack={() => setActiveWorkout(null)}
            updateWorkout={updateWorkout}
          />
        )}
      </div>

      {/* INSTALL BUTTON - Bottom Left */}
      {showInstall && (
        <button
          onClick={handleInstallClick}
          style={{
            position: "fixed",
            bottom: "20px",
            left: "20px",
            padding: "10px 16px",
            borderRadius: "8px",
            border: "none",
            backgroundColor: "#007bff",
            color: "white",
            cursor: "pointer",
            boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
            zIndex: 1000,
          }}
        >
          Download App
        </button>
      )}

    </div>
  );
}

export default App;