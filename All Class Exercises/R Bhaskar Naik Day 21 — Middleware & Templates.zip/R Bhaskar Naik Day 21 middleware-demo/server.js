const express = require("express");
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set("view engine", "ejs");

// logging middleware
app.use((req, res, next) => {
    console.log(`[${req.method}] ${req.url} at ${new Date().toISOString()}`);
    next();
});

// test route
app.get("/courses", (req, res) => {
    res.send("Courses API working");
});

// POST users
app.post("/users", (req, res) => {
    res.json({
        message: "User created successfully",
        data: req.body
    });

});

// template route
app.get("/courses-view", (req, res) => {
    const courses = ["Node.js", "Express", "MongoDB", "React"];
    res.render("courses", { courses });

});

app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});