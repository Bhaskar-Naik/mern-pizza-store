const express = require("express");

const router = express.Router();

/* POST /users */

router.post("/", (req, res) => {

    const user = req.body;

    res.json({
        message: "User created successfully",
        data: user
    });

});

module.exports = router;