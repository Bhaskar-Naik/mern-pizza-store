## User Story 1 - Database Setup

use BookVerseDB

db.Authors.insertMany([...])

db.Books.insertMany([...])

db.Users.insertMany([...])


## User Story 2 - CRUD Operations

db.Books.insertOne({...})          -- Create

db.Books.find({ genre: "Science Fiction" })  -- Read

db.Books.updateOne(
  { title: "Foundation" },
  { $set: { publicationYear: 1952 } }
)          -- Update

db.Users.deleteOne({ name: "Hari" })     -- Delete

db.Books.updateOne(
  { title: "Harry Potter and the Sorcerer's Stone" },
  { $push: { ratings: {...} } }
)     -- Add rating


## User Story 3 - Filtering Queries

db.Books.find({ publicationYear: { $gt: 2015 } })

db.Books.find({ genre: "Fantasy" })

db.Users.find({ joinDate: { $gte: ... } })

db.Books.find({ "ratings.score": { $gt: 4 } })


## To Export .json file

JSON.stringify(db.Authors.find().toArray())

JSON.stringify(db.Books.find().toArray())

JSON.stringify(db.Users.find().toArray())