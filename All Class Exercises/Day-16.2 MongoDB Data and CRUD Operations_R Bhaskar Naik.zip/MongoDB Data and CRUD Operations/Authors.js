[{
  "_id": {
    "$oid": "69a5d9f2b66b78264e7c2907"
  },
  "name": "J.K. Rowling",
  "nationality": "British",
  "birthYear": 1965
},
{
  "_id": {
    "$oid": "69a5d9f2b66b78264e7c2908"
  },
  "name": "Isaac Asimov",
  "nationality": "American",
  "birthYear": 1920
},
{
  "_id": {
    "$oid": "69a5d9f2b66b78264e7c2909"
  },
  "name": "George R.R. Martin",
  "nationality": "American",
  "birthYear": 1948
},
{
  "_id": {
    "$oid": "69a71a304a93ed4cab7c2907"
  },
  "name": "J.K. Rowling",
  "nationality": "British",
  "birthYear": 1965
},
{
  "_id": {
    "$oid": "69a71a304a93ed4cab7c2908"
  },
  "name": "Isaac Asimov",
  "nationality": "American",
  "birthYear": 1920
},
{
  "_id": {
    "$oid": "69a71a304a93ed4cab7c2909"
  },
  "name": "George R.R. Martin",
  "nationality": "American",
  "birthYear": 1948
}]