interface IProduct {
id: number;
name: string;
category: string;
price: number;
stock: number;
}

function LogChange(target: any, propertyKey: string, descriptor: PropertyDescriptor) {
const original = descriptor.value;

descriptor.value = function (...args: any[]) {
console.log(`Updated product: ${this.name}`);
return original.apply(this, args);
};
}

class Product implements IProduct {

constructor(
public id: number,
public name: string,
public category: string,
public price: number,
public stock: number
) {}

@LogChange
updatePrice(newPrice: number) {
this.price = newPrice;
}

@LogChange
updateStock(newStock: number) {
this.stock = newStock;
}
}

const inventory: Map<number, Product> = new Map();

const p1 = new Product(1, "Laptop", "Electronics", 80000, 5);
const p2 = new Product(2, "Sneakers", "Fashion", 3000, 15);

inventory.set(p1.id, p1);
inventory.set(p2.id, p2);

for (const item of inventory.values()) {
console.log(item);
}
