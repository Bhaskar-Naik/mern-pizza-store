var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
function LogChange(target, propertyKey, descriptor) {
    const original = descriptor.value;
    descriptor.value = function (...args) {
        console.log(`Updated product: ${this.name}`);
        return original.apply(this, args);
    };
}
class Product {
    constructor(id, name, category, price, stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }
    updatePrice(newPrice) {
        this.price = newPrice;
    }
    updateStock(newStock) {
        this.stock = newStock;
    }
}
__decorate([
    LogChange
], Product.prototype, "updatePrice", null);
__decorate([
    LogChange
], Product.prototype, "updateStock", null);
const inventory = new Map();
const p1 = new Product(1, "Laptop", "Electronics", 80000, 5);
const p2 = new Product(2, "Sneakers", "Fashion", 3000, 15);
inventory.set(p1.id, p1);
inventory.set(p2.id, p2);
for (const item of inventory.values()) {
    console.log(item);
}
