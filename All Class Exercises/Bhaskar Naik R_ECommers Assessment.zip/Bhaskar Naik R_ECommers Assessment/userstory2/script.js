const container = document.getElementById("productContainer");
const categoryFilter = document.getElementById("categoryFilter");
const sortFilter = document.getElementById("sortFilter");

async function loadProducts() {
try {
container.innerHTML = "Loading...";
const response = await fetch("../userstory2/products.json");
if (!response.ok) throw new Error("Fetch failed");

const data = await response.json();
displayProducts(data);
} catch (err) {
container.innerHTML = "Error loading data";
}
}

function displayProducts(products) {
container.innerHTML = "";

products.forEach(product => {
const div = document.createElement("div");
div.innerHTML = `
<h5>${product.name}</h5>
<p>Category: ${product.category}</p>
<p>Price: ₹${product.price}</p>
<hr>
`;
container.appendChild(div);
});
}

async function applyFilter() {
const response = await fetch("../userstory2/products.json");
let products = await response.json();

if (categoryFilter.value !== "All") {
products = products.filter(p => p.category === categoryFilter.value);
}

if (sortFilter.value === "low") {
products.sort((a,b)=>a.price-b.price);
}
if (sortFilter.value === "high") {
products.sort((a,b)=>b.price-a.price);
}

displayProducts(products);
}

categoryFilter.addEventListener("change", applyFilter);
sortFilter.addEventListener("change", applyFilter);

loadProducts();
