// -----------------------------
// Contact Manager Class
// -----------------------------
class ContactManager {
    constructor() {
        this.contacts = [];
        this.currentId = 1;
        this.loadFromStorage();
    }
    saveToStorage() {
        localStorage.setItem("contacts", JSON.stringify(this.contacts));
    }
    loadFromStorage() {
        const data = localStorage.getItem("contacts");
        if (data) {
            this.contacts = JSON.parse(data);
            this.currentId = this.contacts.length > 0
                ? Math.max(...this.contacts.map(c => c.id)) + 1
                : 1;
        }
    }
    addContact(name, email, phone) {
        if (!name || !email || !phone) {
            return "All fields are required.";
        }
        if (this.contacts.find(c => c.email === email)) {
            return "Email already exists.";
        }
        const newContact = {
            id: this.currentId++,
            name,
            email,
            phone
        };
        this.contacts.push(newContact);
        this.saveToStorage();
        return "Contact added successfully.";
    }
    getContacts() {
        return this.contacts;
    }
    updateContact(id, name, email, phone) {
        const contact = this.contacts.find(c => c.id === id);
        if (!contact) {
            return "Contact not found.";
        }
        contact.name = name;
        contact.email = email;
        contact.phone = phone;
        this.saveToStorage();
        return "Contact updated successfully.";
    }
    deleteContact(id) {
        const index = this.contacts.findIndex(c => c.id === id);
        if (index === -1) {
            return "Contact not found.";
        }
        this.contacts.splice(index, 1);
        this.saveToStorage();
        return "Contact deleted successfully.";
    }
}
// -----------------------------
// UI Logic
// -----------------------------
const manager = new ContactManager();
let editMode = false;
let editId = null;
function showMessage(message, isSuccess) {
    const msgBox = document.getElementById("message");
    msgBox.textContent = message;
    msgBox.style.color = isSuccess ? "green" : "red";
    setTimeout(() => {
        msgBox.textContent = "";
    }, 3000);
}
function renderContacts() {
    const tbody = document.getElementById("contactList");
    tbody.innerHTML = "";
    manager.getContacts().forEach(contact => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${contact.id}</td>
            <td>${contact.name}</td>
            <td>${contact.email}</td>
            <td>${contact.phone}</td>
            <td>
                <button onclick="editContact(${contact.id})">Edit</button>
                <button onclick="deleteContactUI(${contact.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}
function handleSubmit() {
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    let result;
    if (editMode && editId !== null) {
        result = manager.updateContact(editId, name, email, phone);
        editMode = false;
        editId = null;
    }
    else {
        result = manager.addContact(name, email, phone);
    }
    showMessage(result, result.includes("successfully"));
    renderContacts();
    document.getElementById("contactForm").reset();
}
function editContact(id) {
    const contact = manager.getContacts().find(c => c.id === id);
    if (!contact)
        return;
    document.getElementById("name").value = contact.name;
    document.getElementById("email").value = contact.email;
    document.getElementById("phone").value = contact.phone;
    editMode = true;
    editId = id;
}
function deleteContactUI(id) {
    const result = manager.deleteContact(id);
    showMessage(result, result.includes("successfully"));
    renderContacts();
}
window.onload = function () {
    renderContacts();
};
function modifyById() {
    const id = Number(document.getElementById("modifyId").value);
    const name = document.getElementById("modifyName").value.trim();
    const email = document.getElementById("modifyEmail").value.trim();
    const phone = document.getElementById("modifyPhone").value.trim();
    const result = manager.updateContact(id, name, email, phone);
    showMessage(result, result.includes("successfully"));
    renderContacts();
}
function deleteById() {
    const id = Number(document.getElementById("deleteId").value);
    const result = manager.deleteContact(id);
    showMessage(result, result.includes("successfully"));
    renderContacts();
}
