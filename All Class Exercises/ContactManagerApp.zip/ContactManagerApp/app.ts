// Contact Interface

interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

// Contact Manager Class
class ContactManager {
    private contacts: Contact[] = [];
    private currentId: number = 1;

    constructor() {
        this.loadFromStorage();
    }

    private saveToStorage(): void {
        localStorage.setItem("contacts", JSON.stringify(this.contacts));
    }

    private loadFromStorage(): void {
        const data = localStorage.getItem("contacts");
        if (data) {
            this.contacts = JSON.parse(data);
            this.currentId = this.contacts.length > 0
                ? Math.max(...this.contacts.map(c => c.id)) + 1
                : 1;
        }
    }

    addContact(name: string, email: string, phone: string): string {
        if (!name || !email || !phone) {
            return "All fields are required.";
        }

        if (this.contacts.find(c => c.email === email)) {
            return "Email already exists.";
        }

        const newContact: Contact = {
            id: this.currentId++,
            name,
            email,
            phone
        };

        this.contacts.push(newContact);
        this.saveToStorage();
        return "Contact added successfully.";
    }

    getContacts(): Contact[] {
        return this.contacts;
    }

    updateContact(id: number, name: string, email: string, phone: string): string {
        const contact = this.contacts.find(c => c.id === id);
        if (!contact) {
            return "Contact not found.";
        }

        contact.name = name;
        contact.email = email;
        contact.phone = phone;

        this.saveToStorage();
        return "Contact updated successfully.";
    }

    deleteContact(id: number): string {
        const index = this.contacts.findIndex(c => c.id === id);
        if (index === -1) {
            return "Contact not found.";
        }

        this.contacts.splice(index, 1);
        this.saveToStorage();
        return "Contact deleted successfully.";
    }
}

// UI Logic
const manager = new ContactManager();
let editMode = false;
let editId: number | null = null;

function showMessage(message: string, isSuccess: boolean): void {
    const msgBox = document.getElementById("message") as HTMLElement;
    msgBox.textContent = message;
    msgBox.style.color = isSuccess ? "green" : "red";

    setTimeout(() => {
        msgBox.textContent = "";
    }, 3000);
}

function renderContacts(): void {
    const tbody = document.getElementById("contactList") as HTMLElement;
    tbody.innerHTML = "";

    manager.getContacts().forEach(contact => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${contact.id}</td>
            <td>${contact.name}</td>
            <td>${contact.email}</td>
            <td>${contact.phone}</td>
            <td>
                <button onclick="editContact(${contact.id})">Edit</button>
                <button onclick="deleteContactUI(${contact.id})">Delete</button>
            </td>
        `;

        tbody.appendChild(row);
    });
}

function handleSubmit(): void {
    const name = (document.getElementById("name") as HTMLInputElement).value.trim();
    const email = (document.getElementById("email") as HTMLInputElement).value.trim();
    const phone = (document.getElementById("phone") as HTMLInputElement).value.trim();

    let result: string;

    if (editMode && editId !== null) {
        result = manager.updateContact(editId, name, email, phone);
        editMode = false;
        editId = null;
    } else {
        result = manager.addContact(name, email, phone);
    }

    showMessage(result, result.includes("successfully"));
    renderContacts();

    (document.getElementById("contactForm") as HTMLFormElement).reset();
}

function editContact(id: number): void {
    const contact = manager.getContacts().find(c => c.id === id);
    if (!contact) return;

    (document.getElementById("name") as HTMLInputElement).value = contact.name;
    (document.getElementById("email") as HTMLInputElement).value = contact.email;
    (document.getElementById("phone") as HTMLInputElement).value = contact.phone;

    editMode = true;
    editId = id;
}

function deleteContactUI(id: number): void {
    const result = manager.deleteContact(id);
    showMessage(result, result.includes("successfully"));
    renderContacts();
}

window.onload = function () {
    renderContacts();
};
