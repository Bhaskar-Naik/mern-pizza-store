import React, { useState } from "react";
import Navbar from "./components/Navbar";
import LazyLoadingSection from "./components/LazyLoadingSection";
import PureComponentsSection from "./components/PureComponentsSection";
import ErrorBoundarySection from "./components/ErrorBoundarySection";
import PortalSection from "./components/PortalSection";

function App() {

  const [activeSection, setActiveSection] = useState(null);

  const toggleSection = (section) => {
    setActiveSection(prev => prev === section ? null : section);
  };

  return (
    <div>

      <header className="hero">
        <h1>Online Learning Platform</h1>
        <p className="subtitle">Interactive Learning Platform</p>
        <p>
          Master lazy loading, pure components, error boundaries,
          and portals through interactive examples.
        </p>
      </header>

      <Navbar toggleSection={toggleSection} active={activeSection} />

      <div className="content-area">

        {activeSection === "lazy" && <LazyLoadingSection />}
        {activeSection === "pure" && <PureComponentsSection />}
        {activeSection === "error" && <ErrorBoundarySection />}
        {activeSection === "portal" && <PortalSection />}

      </div>

    </div>
  );
}

export default App;