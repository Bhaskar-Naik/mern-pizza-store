function CourseCard({ onDetails, onInstructor }) {
  return (
    <div className="course-card">
      <img
        src="https://images.unsplash.com/photo-1584697964403-9b28f93b3c75"
        alt="Course"
      />
      <div>
        <h4>Advanced React Mastery</h4>
        <p>Learn performance optimization and architecture.</p>
        <button onClick={onDetails}>View Details</button>
        <button onClick={onInstructor}>Instructor</button>
      </div>
    </div>
  );
}

export default CourseCard;