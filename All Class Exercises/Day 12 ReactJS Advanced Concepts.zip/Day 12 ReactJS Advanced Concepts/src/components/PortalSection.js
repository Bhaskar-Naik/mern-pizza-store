import React, { useState } from "react";
import Modal from "./Modal";
import Toast from "./Toast";

function PortalSection() {

  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState(null);

  const showNotification = (type) => {
    setToast(type);
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div className="section">

      <h2>React Portals</h2>

      <div className="button-row">
        <button onClick={() => setShowModal(true)}>
          Open Modal
        </button>

        <button onClick={() => showNotification("success")}>
          Success
        </button>

        <button onClick={() => showNotification("error")}>
          Error
        </button>

        <button onClick={() => showNotification("info")}>
          Info
        </button>
      </div>

      {showModal && (
        <Modal onClose={() => setShowModal(false)}>
          <h3>Enrollment Modal</h3>
          <p>This modal uses React Portal.</p>
        </Modal>
      )}

      {toast && <Toast type={toast} />}

    </div>
  );
}

export default PortalSection;