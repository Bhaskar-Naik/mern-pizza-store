import React from "react";

const StatsCard = React.memo(({ title, value }) => {

  console.log(title + " rendered");

  return (
    <div className="stats-card">
      <h4>{title}</h4>
      <p>{value}</p>
      <small>Updated: {new Date().toLocaleTimeString()}</small>
    </div>
  );
});

export default StatsCard;