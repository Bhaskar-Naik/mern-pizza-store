function CourseDetails() {
  return (
    <div className="card">

      <h3>React Advanced Patterns</h3>

      <p>
        Master advanced React concepts including lazy loading,
        code splitting, pure components, error boundaries,
        and portals. Build production-ready applications
        with optimal performance.
      </p>

      <div className="course-meta">
        <span>12 hours</span>
        <span>4 weeks</span>
        <span>Certificate</span>
        <span>Advanced</span>
      </div>

      <h4>Course Syllabus</h4>

      <ul>
        <li>React Hooks Deep Dive</li>
        <li>Performance Optimization</li>
        <li>Advanced State Management</li>
        <li>Custom Hooks Development</li>
        <li>Testing Best Practices</li>
      </ul>

    </div>
  );
}

export default CourseDetails;