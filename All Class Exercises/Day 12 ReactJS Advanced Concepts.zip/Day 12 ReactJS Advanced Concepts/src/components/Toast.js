import ReactDOM from "react-dom";

function Toast({ type }) {

  return ReactDOM.createPortal(
    <div className={`toast ${type}`}>
      {type.toUpperCase()} Notification
    </div>,
    document.body
  );
}

export default Toast;