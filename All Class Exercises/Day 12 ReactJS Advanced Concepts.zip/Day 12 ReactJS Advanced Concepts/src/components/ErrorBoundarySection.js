import React, { useState } from "react";
import ErrorBoundary from "./ErrorBoundary";
import BuggyComponent from "./BuggyComponent";

function ErrorBoundarySection() {

  const [crash, setCrash] = useState(false);

  return (
    <div className="section">

      <h2>Error Boundaries</h2>

      <p>
        Error boundaries catch JavaScript errors in child components,
        log them, and display fallback UI.
      </p>

      <button onClick={() => setCrash(true)}>
        Trigger Error
      </button>

      <div className="error-demo">

        <div className="card">
          <h4>Working Component</h4>
          <p>This component continues functioning normally.</p>
        </div>

        <ErrorBoundary>
          <BuggyComponent crash={crash} />
        </ErrorBoundary>

      </div>

    </div>
  );
}

export default ErrorBoundarySection;