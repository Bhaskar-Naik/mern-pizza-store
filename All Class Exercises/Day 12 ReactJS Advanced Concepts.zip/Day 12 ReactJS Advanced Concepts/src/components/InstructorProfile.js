function InstructorProfile() {
  return (
    <div className="card">

      <h3>Meet Your Teacher</h3>

      <img
        src="https://scontent.fmyq1-1.fna.fbcdn.net/v/t39.30808-6/590793050_1289234119913944_4698507338195830276_n.jpg?_nc_cat=101&ccb=1-7&_nc_sid=7b2446&_nc_ohc=tjVOtQK7FloQ7kNvwFmikTO&_nc_oc=Adm6HT3ujgCza7DiiJf1ymsFG_MPZEddyS8gr3J5b3HKHZMihYuJbrcCrVH4hK2uLhQ&_nc_zt=23&_nc_ht=scontent.fmyq1-1.fna&_nc_gid=IYppmerScczvyi4T7wCAfA&oh=00_Aft7MLZy54q_BQrq4JL_XOHuvb3DY0ZrM7subaNbP6c1yQ&oe=69A0C82C"
        alt="Instructor"
        className="instructor-img"
      />

      <h4>Dr. Abhishek Sharma</h4>
      <p>Senior React Engineer</p>

      <p>
        With 10+ years experience building scalable applications.
      </p>

    </div>
  );
}

export default InstructorProfile;