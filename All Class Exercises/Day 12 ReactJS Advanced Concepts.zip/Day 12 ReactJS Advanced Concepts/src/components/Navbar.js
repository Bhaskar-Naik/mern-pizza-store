function Navbar({ toggleSection, active }) {
  return (
    <nav className="navbar-horizontal">

      <button
        className={active === "lazy" ? "active" : ""}
        onClick={() => toggleSection("lazy")}
      >
        Lazy Loading & Code Splitting
      </button>

      <button
        className={active === "pure" ? "active" : ""}
        onClick={() => toggleSection("pure")}
      >
        Pure Components
      </button>

      <button
        className={active === "error" ? "active" : ""}
        onClick={() => toggleSection("error")}
      >
        Error Boundaries
      </button>

      <button
        className={active === "portal" ? "active" : ""}
        onClick={() => toggleSection("portal")}
      >
        React Portals
      </button>

    </nav>
  );
}

export default Navbar;