import React, { useState } from "react";
import StatsCard from "./StatsCard";

function PureComponentsSection() {

  const [stats, setStats] = useState({
    users: 1250,
    sessions: 342,
    revenue: 45678,
    bounce: 23
  });

  const [updateCount, setUpdateCount] = useState(0);

  const updateStat = (key) => {
    setStats(prev => ({
      ...prev,
      [key]: prev[key] + 1
    }));
    setUpdateCount(prev => prev + 1);
  };

  const updateAll = () => {
    setStats(prev => ({
      users: prev.users + 1,
      sessions: prev.sessions + 1,
      revenue: prev.revenue + 1,
      bounce: prev.bounce + 1
    }));
    setUpdateCount(prev => prev + 1);
  };

  return (
    <div className="section">

      <h2>Pure Components</h2>

      <p>
        These cards use React.memo to prevent unnecessary re-renders.
        Check console to observe optimized rendering.
      </p>

      <div className="stats-grid">
        <StatsCard title="Total Users" value={stats.users} />
        <StatsCard title="Active Sessions" value={stats.sessions} />
        <StatsCard title="Revenue" value={stats.revenue} />
        <StatsCard title="Bounce Rate" value={stats.bounce} />
      </div>

      <div className="button-row">
        <button onClick={() => updateStat("users")}>Update Total Users</button>
        <button onClick={() => updateStat("sessions")}>Update Active Sessions</button>
        <button onClick={() => updateStat("revenue")}>Update Revenue</button>
        <button onClick={() => updateStat("bounce")}>Update Bounce Rate</button>
        <button onClick={updateAll}>Update All</button>
      </div>

      <p>Total updates triggered: {updateCount}</p>

    </div>
  );
}

export default PureComponentsSection;