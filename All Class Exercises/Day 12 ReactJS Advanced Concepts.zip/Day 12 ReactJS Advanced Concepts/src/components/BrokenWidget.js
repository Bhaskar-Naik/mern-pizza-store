function BrokenWidget() {
  throw new Error("Simulated Crash");
}

export default BrokenWidget;