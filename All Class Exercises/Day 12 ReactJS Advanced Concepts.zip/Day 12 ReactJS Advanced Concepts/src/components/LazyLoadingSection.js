import React, { Suspense, useState } from "react";

const CourseDetails = React.lazy(() => import("./CourseDetails"));
const InstructorProfile = React.lazy(() => import("./InstructorProfile"));

function LazyLoadingSection() {

  const [view, setView] = useState(null);

  const toggleView = (type) => {
    setView(prev => prev === type ? null : type);
  };

  return (
    <div className="section">

      <h2>Lazy Loading & Code Splitting</h2>

      <p>
        Load components only when needed to improve initial load time.
      </p>

      <div className="button-row">
        <button onClick={() => toggleView("details")}>
          Course Details
        </button>
        <button onClick={() => toggleView("instructor")}>
          Instructor Profile
        </button>
      </div>

      <Suspense fallback={<div className="loader"></div>}>
        {view === "details" && <CourseDetails />}
        {view === "instructor" && <InstructorProfile />}
      </Suspense>

    </div>
  );
}

export default LazyLoadingSection;