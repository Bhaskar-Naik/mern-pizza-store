function BuggyComponent({ crash }) {

  if (crash) {
    throw new Error("Simulated component crash!");
  }

  return (
    <div className="card">
      <h4>Protected Component</h4>
      <p>This area is protected by an error boundary.</p>
    </div>
  );
}

export default BuggyComponent;