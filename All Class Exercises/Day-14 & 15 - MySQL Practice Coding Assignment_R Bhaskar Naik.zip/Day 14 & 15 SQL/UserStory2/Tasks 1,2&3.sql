INSERT INTO Department (DeptName, Location) VALUES
('HR', 'Hyderabad'),
('IT', 'Bangalore'),
('Finance', 'Mumbai'),
('Marketing', 'Chennai'),
('Operations', 'Delhi');
INSERT INTO Employee (EmpName, Gender, DOB, HireDate, DeptID) VALUES
('Amit Sharma', 'Male', '1998-04-12', '2022-01-10', 2),
('Priya Reddy', 'Female', '1999-06-25', '2021-03-15', 1),
('Rahul Verma', 'Male', '1997-09-18', '2020-07-22', 3),
('Sneha Iyer', 'Female', '2000-11-30', '2023-02-05', 2),
('Kiran Patel', 'Other', '1996-01-08', '2019-12-01', 4);
INSERT INTO Project (ProjectName, DeptID, StartDate, EndDate) VALUES
('HRMS Development', 1, '2024-01-01', '2024-06-30'),
('Inventory System', 2, '2024-02-01', '2024-08-31'),
('Financial Audit Tool', 3, '2024-03-01', NULL),
('Marketing Campaign App', 4, '2024-04-15', NULL),
('Operations Tracker', 5, '2024-05-01', NULL);
INSERT INTO Performance (EmpID, ProjectID, Rating, ReviewDate) VALUES
(1, 2, 5, '2024-07-01'),
(2, 1, 4, '2024-07-02'),
(3, 3, 3, '2024-07-03'),
(4, 2, 5, '2024-07-04'),
(5, 4, 2, '2024-07-05');

INSERT INTO Reward (EmpID, RewardMonth, RewardAmount) VALUES
(1, '2024-07-01', 5000.00),

UPDATE Employee
SET DeptID = 3
WHERE EmpID = 1;

SELECT EmpID, EmpName, DeptID FROM Employee WHERE EmpID = 1;
(2, '2024-07-01', 800.00),
(3, '2024-07-01', 3000.00),
(4, '2024-07-01', 1500.00),
(5, '2024-07-01', 900.00);-- 
DELETE FROM Reward
WHERE RewardAmount < 1000;
SELECT * FROM Reward;