INSERT INTO Department (DeptName, Location)
VALUES 
('HR', 'Hyderabad'),
('IT', 'Bangalore'),
('Finance', 'Mumbai');
INSERT INTO Employee (EmpName, Gender, DOB, HireDate, DeptID)
VALUES
('Bhaskar', 'Male', '2002-05-10', '2024-01-15', 2),
('Suman', 'Female', '2001-03-12', '2023-07-20', 1);