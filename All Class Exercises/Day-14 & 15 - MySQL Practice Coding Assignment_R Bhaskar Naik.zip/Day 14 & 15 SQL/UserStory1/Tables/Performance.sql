use technovaDB;
create table Performance(
EmpID int not null,
ProjectID int not null,
Rating int not null,
ReviewDate date not null,
primary key (EmpID, ProjectID),
constraint fk_pref_emp
foreign key (EmpID) references employee(EmpID)
on delete cascade
on update cascade,

constraint fk_perf_emp
foreign key (ProjectID) references Project (ProjectID)
on delete cascade
on update cascade,

constraint chk_rating
check (Rating between 1 and 5)
);