use TechNovaDB;
create table Project(
ProjectID int auto_increment primary key,
ProjectName varchar(100) not null,
DeptID int,
StartDate date not null,
EndDate date,
foreign key (DeptID) references Department(DeptID)
);