use TechNovaDB;
CREATE TABLE Reward (
    EmpID INT NOT NULL,
    RewardMonth DATE NOT NULL,
    RewardAmount DECIMAL(10,2) NOT NULL,
    
    PRIMARY KEY (EmpID, RewardMonth),
    
    CONSTRAINT fk_reward_emp
        FOREIGN KEY (EmpID)
        REFERENCES Employee(EmpID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
        
    CONSTRAINT chk_reward_amount
        CHECK (RewardAmount >= 0)
);