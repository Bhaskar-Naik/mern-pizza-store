create database TechNovaDB;
use TechNovaDB;