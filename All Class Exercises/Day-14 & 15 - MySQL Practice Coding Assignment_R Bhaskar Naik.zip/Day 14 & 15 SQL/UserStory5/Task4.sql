CREATE INDEX idx_perf_emp ON Performance(EmpID);
CREATE INDEX idx_perf_proj ON Performance(ProjectID);
CREATE INDEX idx_emp_dept ON Employee(DeptID);
CREATE INDEX idx_proj_dept ON Project(DeptID);