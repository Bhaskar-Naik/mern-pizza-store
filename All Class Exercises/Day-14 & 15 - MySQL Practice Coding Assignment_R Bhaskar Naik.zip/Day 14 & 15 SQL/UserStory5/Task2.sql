DELIMITER //

CREATE PROCEDURE AddEmployeeTransaction()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
    END;

    START TRANSACTION;

    INSERT INTO Employee (EmpName, Gender, DOB, HireDate, DeptID)
    VALUES ('Ravi Kumar', 'Male', '2000-05-10', CURDATE(), 3);

    SET @NewEmpID = LAST_INSERT_ID();

    INSERT INTO Performance (EmpID, ProjectID, Rating, ReviewDate)
    VALUES (@NewEmpID, 3, 5, CURDATE());

    COMMIT;
END //

DELIMITER ;