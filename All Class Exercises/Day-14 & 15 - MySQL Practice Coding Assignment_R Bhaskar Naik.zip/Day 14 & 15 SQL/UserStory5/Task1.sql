START TRANSACTION;

-- Step 1: Insert new employee
INSERT INTO Employee (EmpName, Gender, DOB, HireDate, DeptID)
VALUES ('Arjun Rao', 'Male', '2001-08-15', CURDATE(), 2);

-- Step 2: Get the last inserted EmpID
SET @NewEmpID = LAST_INSERT_ID();

-- Step 3: Insert performance record
INSERT INTO Performance (EmpID, ProjectID, Rating, ReviewDate)
VALUES (@NewEmpID, 2, 4, CURDATE());

COMMIT;