SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID FROM Reward
);