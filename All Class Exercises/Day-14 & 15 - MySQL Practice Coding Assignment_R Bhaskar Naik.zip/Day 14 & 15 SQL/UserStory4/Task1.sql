SELECT 
    e.EmpName,
    d.DeptName,
    pr.ProjectName,
    p.Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
JOIN Project pr ON p.ProjectID = pr.ProjectID
ORDER BY d.DeptName, e.EmpName;