#task 1

SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

#task 2
SELECT 
    d.DeptName,
    ROUND(AVG(p.Rating), 2) AS Average_Rating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName; 

#task 3
SELECT 
    EmpName,
    DOB,
    TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

# task 4

SELECT 
    SUM(RewardAmount) AS Total_Rewards_Current_Year
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

# Task 5
SELECT 
    e.EmpID,
    e.EmpName,
    r.RewardAmount,
    r.RewardMonth
FROM Reward r
JOIN Employee e ON r.EmpID = e.EmpID
WHERE r.RewardAmount > 2000;
