import React, { Component } from "react";

class AuthorInfo extends Component {
  render() {
    const { author } = this.props;

    const authorData = {
      "James Clear": {
        bio: "James Clear is a writer and speaker focused on habits, decision making, and continuous improvement.",
        books: [
          "Atomic Habits",
          "Mastering Habits",
          "Habit Growth"
        ]
      },

      "Paulo Coelho": {
        bio: "Paulo Coelho is a Brazilian novelist best known for his inspirational and philosophical storytelling.",
        books: [
          "The Alchemist",
          "Brida",
          "Eleven Minutes"
        ]
      },

      "A.P.J. Abdul Kalam": {
        bio: "Dr. A.P.J. Abdul Kalam was an Indian aerospace scientist and the 11th President of India, known as the Missile Man of India.",
        books: [
          "Wings of Fire",
          "Ignited Minds",
          "India 2020"
        ]
      },

      "Hector Garcia": {
        bio: "Hector Garcia is a Spanish author known for exploring Japanese culture and philosophy.",
        books: [
          "Ikigai",
          "A Geek in Japan",
          "The Book of Ichigo Ichie"
        ]
      }
    };

    const info = authorData[author];

    if (!info) return null;

    return (
      <div className="card mt-4 p-3 shadow-sm">
        <h5>About the Author</h5>
        <p>{info.bio}</p>

        <h6 className="mt-3">Top 3 Books:</h6>
        <ul>
          {info.books.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;