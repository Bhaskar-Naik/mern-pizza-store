import { Link } from "react-router-dom";

function BookCard({ book }) {
  return (
    <div className="col-lg-3 col-md-6 mb-4 d-flex justify-content-center">
      <div className="card book-card shadow-sm">

        <img
          src={book.image}
          className="card-img-top book-image"
          alt={book.title}
        />

        <div className="card-body text-center p-2">
          <h6 className="mb-1">{book.title}</h6>
          <p className="small text-muted mb-2">{book.author}</p>

          <Link
            to={`/book/${book.id}`}
            className="btn btn-sm btn-primary"
          >
            View Details
          </Link>
        </div>

      </div>
    </div>
  );
}

export default BookCard;