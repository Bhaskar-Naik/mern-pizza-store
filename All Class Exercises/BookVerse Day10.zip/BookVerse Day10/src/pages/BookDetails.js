import { useParams, Link } from "react-router-dom";
import DataProvider from "../components/DataProvider";
import withLoader from "../components/withLoader";
import AuthorInfo from "../components/AuthorInfo";

function BookDetails() {
  const { id } = useParams();

  return (
    <div className="container mt-5">
      <DataProvider url={`http://localhost:3001/books/${id}`}>
        {({ data, loading }) => {

          const DetailsComponent = ({ book }) => (
            <div className="card shadow p-4">
              <div className="row">
                <div className="col-md-4">
                  <img
                    src={book.image}
                    className="img-fluid rounded"
                    alt={book.title}
                  />
                </div>

                <div className="col-md-8">
                  <h3>{book.title}</h3>
                  <p><strong>Author:</strong> {book.author}</p>
                  <p>{book.description}</p>
                  <h5>₹ {book.price}</h5>

                  {/*Author Class Component*/}
                  <AuthorInfo author={book.author} />

                  <Link to="/" className="btn btn-secondary mt-3">
                    Back
                  </Link>
                </div>
              </div>
            </div>
          );

          const DetailsWithLoader = withLoader(DetailsComponent);

          return (
            <DetailsWithLoader
              isLoading={loading}
              book={data}
            />
          );
        }}
      </DataProvider>
    </div>
  );
}

export default BookDetails;