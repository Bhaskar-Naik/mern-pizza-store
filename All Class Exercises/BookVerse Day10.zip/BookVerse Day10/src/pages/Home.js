import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import BookCard from "../components/BookCard";
import DataProvider from "../components/DataProvider";
import withLoader from "../components/withLoader";

function Home() {
  const searchRef = useRef(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [viewType, setViewType] = useState("grid");

  const focusSearch = () => {
    if (searchRef.current) {
      searchRef.current.focus();
    }
  };

  return (
    <>
      {/*Navbar*/}
      <nav className="navbar navbar-expand-lg navbar-custom px-4">
        <div className="container-fluid">
          <span className="navbar-brand text-white fw-bold">
            BookVerse
          </span>
          <div className="ms-auto">
            <button className="btn btn-light" onClick={focusSearch}>
              Focus Search
            </button>
          </div>
        </div>
      </nav>

      <div className="container mt-4">

        {/*Page Heading*/}
        <div className="text-center mb-4">
          <h1 className="fw-bold">BookVerse</h1>
          <p className="text-muted">Welcome to the Books Section</p>
        </div>

        {/*Search and View Toggle*/}
        <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">

          <input
            type="text"
            ref={searchRef}
            className="form-control search-box"
            placeholder="Search books..."
            onChange={(e) => setSearchTerm(e.target.value)}
          />

          <div>
            <button
              className={`btn me-2 ${
                viewType === "grid"
                  ? "btn-primary"
                  : "btn-outline-primary"
              }`}
              onClick={() => setViewType("grid")}
            >
              Grid
            </button>

            <button
              className={`btn ${
                viewType === "list"
                  ? "btn-primary"
                  : "btn-outline-primary"
              }`}
              onClick={() => setViewType("list")}
            >
              List
            </button>
          </div>
        </div>

        {/*Data Fetch*/}
        <DataProvider url="http://localhost:3001/books">
          {({ data, loading }) => {

            const filteredBooks = data.filter((book) =>
              book.title
                .toLowerCase()
                .includes(searchTerm.toLowerCase())
            );

            const BookListComponent = ({ books }) => {

              /*LIST VIEW*/
              if (viewType === "list") {
                return (
                  <div>
                    {books.map((book) => (
                      <div
                        key={book.id}
                        className="card mb-3 shadow-sm p-3"
                      >
                        <div className="row g-0 align-items-center">

                          <div className="col-md-2 text-center">
                            <img
                              src={book.image}
                              alt={book.title}
                              className="img-fluid rounded"
                              style={{
                                maxHeight: "150px",
                                objectFit: "contain"
                              }}
                            />
                          </div>

                          <div className="col-md-8">
                            <h5>{book.title}</h5>
                            <p className="mb-1 text-muted">
                              {book.author}
                            </p>
                            <p className="mb-1 small">
                              {book.description}
                            </p>
                            <strong>₹ {book.price}</strong>
                          </div>

                          <div className="col-md-2 d-flex align-items-center justify-content-center">
                            <Link
                              to={`/book/${book.id}`}
                              className="btn btn-sm btn-primary"
                            >
                              View Details
                            </Link>
                          </div>

                        </div>
                      </div>
                    ))}
                  </div>
                );
              }

              /* GRID VIEW*/
              return (
                <div className="row">
                  {books.map((book) => (
                    <BookCard
                      key={book.id}
                      book={book}
                    />
                  ))}
                </div>
              );
            };

            const BookListWithLoader =
              withLoader(BookListComponent);

            return (
              <BookListWithLoader
                isLoading={loading}
                books={filteredBooks}
              />
            );
          }}
        </DataProvider>

      </div>
    </>
  );
}

export default Home;