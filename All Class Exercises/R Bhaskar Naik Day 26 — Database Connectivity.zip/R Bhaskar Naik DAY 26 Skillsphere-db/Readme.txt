Day 26 - Database Connectivity

This project is about connecting SkillSphere to MySQL and MongoDB databases and using Sequelize ORM.

How to set up

Install the required packages by opening the terminal in VS Code and running:
npm install mysql2 mongoose sequelize dotenv

Create a .env file in the root of your project and add your database credentials:
MYSQL_HOST=localhost
MYSQL_USER=root
MYSQL_PASSWORD=yourpassword
MYSQL_DB=skillsphere
MONGO_URI=mongodb://localhost:27017/skillsphere

MySQL Setup

Open MySQL Workbench or the MySQL shell and run the following to create the database and table:
CREATE DATABASE skillsphere;
USE skillsphere;
CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

Challenge 1 - MySQL Integration

File: mysql-insert.js
Run it in the VS Code terminal: node mysql-insert.js
It will connect to MySQL and insert a course into the courses table.
To verify, open MySQL Workbench and run: SELECT * FROM courses;

Challenge 2 - MongoDB Integration

Files: models/User.js, models/Enrollment.js, mongo-fetch.js
Make sure MongoDB is running before you run this file.
Run it in the VS Code terminal: node mongo-fetch.js
It will create a user and an enrollment and then fetch and display them.
To verify, open MongoDB Compass or the mongo shell and check the skillsphere database.

Challenge 3 - Sequelize ORM

Files: sequelize/db.js, sequelize/Instructor.js, sequelize/Course.js, sequelize/index.js, sequelize-query.js
Run it in the VS Code terminal: node sequelize-query.js
It will create an instructor, add two courses linked to that instructor, and then fetch and display them.
To verify, open MySQL Workbench and run:
SELECT * FROM Instructors;
SELECT * FROM Courses;

Project structure

skillsphere-db
.env
package.json
mysql-insert.js
mongo-fetch.js
models
  User.js
  Enrollment.js
sequelize
  db.js
  Instructor.js
  Course.js
  index.js
sequelize-query.js