// mongo-fetch.js
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const Enrollment = require('./models/Enrollment');

async function run() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log(' Connected to MongoDB');

  // Seed a user
  const user = await User.create({ name: 'Alice', email: 'alice@skillsphere.com' });
  console.log(' User created:', user.name);

  // Seed an enrollment
  const enrollment = await Enrollment.create({
    userId: user._id,
    courseTitle: 'Node.js Mastery'
  });
  console.log(' Enrollment created for course:', enrollment.courseTitle);

  // Fetch enrollments with user details
  const enrollments = await Enrollment.find().populate('userId', 'name email');
  console.log('\n Enrollment Details:');
  enrollments.forEach(e => {
    console.log(`- ${e.userId.name} enrolled in "${e.courseTitle}" on ${e.enrolledAt.toDateString()}`);
  });

  await mongoose.disconnect();
}

run().catch(console.error);