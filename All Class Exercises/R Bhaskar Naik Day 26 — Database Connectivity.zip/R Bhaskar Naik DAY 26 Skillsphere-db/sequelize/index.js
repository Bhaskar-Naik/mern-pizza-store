// sequelize/index.js
const sequelize = require('./db');
const Instructor = require('./Instructor');
const Course = require('./Course');

// One-to-Many: Instructor has many Courses
Instructor.hasMany(Course, { foreignKey: 'instructorId' });
Course.belongsTo(Instructor, { foreignKey: 'instructorId' });

module.exports = { sequelize, Instructor, Course };