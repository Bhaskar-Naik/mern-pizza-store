// sequelize/Instructor.js
const { DataTypes } = require('sequelize');
const sequelize = require('./db');

const Instructor = sequelize.define('Instructor', {
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false, unique: true }
});

module.exports = Instructor;