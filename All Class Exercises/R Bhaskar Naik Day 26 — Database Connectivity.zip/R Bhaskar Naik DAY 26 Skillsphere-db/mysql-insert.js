// mysql-insert.js
require('dotenv').config();
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DB
});

connection.connect((err) => {
  if (err) return console.error('Connection failed:', err.message);
  console.log(' Connected to MySQL');

  const course = {
    title: 'Node.js Mastery',
    description: 'Learn Node.js from scratch to advanced'
  };

  const sql = 'INSERT INTO courses (title, description) VALUES (?, ?)';
  connection.query(sql, [course.title, course.description], (err, result) => {
    if (err) return console.error('Insert failed:', err.message);
    console.log(' Course inserted! Row ID:', result.insertId);
    connection.end();
  });
});