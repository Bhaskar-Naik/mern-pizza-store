// sequelize-query.js
const { sequelize, Instructor, Course } = require('./sequelize/index');

async function run() {
  // Sync all models (creates tables if not exist)
  await sequelize.sync({ force: true });
  console.log(' Tables synced');

  // Seed instructor
  const instructor = await Instructor.create({
    name: 'Bob Smith',
    email: 'bob@skillsphere.com'
  });

  // Seed courses for this instructor
  await Course.bulkCreate([
    { title: 'React Fundamentals', description: 'Learn React', instructorId: instructor.id },
    { title: 'Advanced Node.js', description: 'Deep dive into Node', instructorId: instructor.id }
  ]);
  console.log(' Instructor and courses seeded');

  // Query: Get all courses by this instructor
  const result = await Instructor.findOne({
    where: { id: instructor.id },
    include: [{ model: Course }]
  });

  console.log(`\n Courses by ${result.name}:`);
  result.Courses.forEach(c => console.log(`  - ${c.title}: ${c.description}`));

  await sequelize.close();
}

run().catch(console.error);