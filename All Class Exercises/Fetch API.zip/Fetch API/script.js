const DashboardApp = (function () {

    const POSTS_URL = "https://jsonplaceholder.typicode.com/posts";
    const TODOS_URL = "https://jsonplaceholder.typicode.com/todos";

    const postsContainer = document.getElementById("postsContainer");
    const todosContainer = document.getElementById("todosContainer");
    const blogSection = document.getElementById("blogSection");
    const todoSection = document.getElementById("todoSection");
    const errorMessage = document.getElementById("errorMessage");
    const loader = document.getElementById("loader");

    const indianBlogs = [
        {
            title: "Digital India: Transforming Governance",
            content: "Digital India has strengthened public service delivery through online systems, digital identity platforms, and improved transparency across departments."
        },
        {
            title: "UPI: India's Payment Revolution",
            content: "UPI has enabled instant bank transfers, empowering small businesses and accelerating India's transition toward a cashless economy."
        },
        {
            title: "Rise of Indian Startups",
            content: "Bengaluru, Hyderabad, and Mumbai have become innovation hubs driving fintech, edtech, and AI transformation."
        },
        {
            title: "ISRO and Space Leadership",
            content: "India's cost-efficient space missions have enhanced the country's scientific credibility and technological capability."
        }
    ];

    const indianTasks = [
        "Prepare Digital India progress summary",
        "Review UPI transaction performance",
        "Attend startup investor meeting",
        "Submit quarterly compliance report"
    ];

    function showLoader() {
        loader.classList.remove("hidden");
    }

    function hideLoader() {
        loader.classList.add("hidden");
    }

    function showBlogOnly() {
        blogSection.classList.remove("hidden");
        todoSection.classList.add("hidden");
    }

    function showTodoOnly() {
        todoSection.classList.remove("hidden");
        blogSection.classList.add("hidden");
    }

    async function fetchData(url) {
        try {
            showLoader();
            errorMessage.textContent = "";

            const response = await fetch(url);

            if (!response.ok) {
                throw new Error("Server connection failed.");
            }

            const data = await response.json();

            if (!Array.isArray(data)) {
                throw new Error("Invalid response format.");
            }

            return data;

        } catch (err) {
            errorMessage.textContent = err.message;
            return null;
        } finally {
            hideLoader();
        }
    }

    function renderPosts() {
        postsContainer.innerHTML = "";
        indianBlogs.forEach(blog => {
            const card = document.createElement("div");
            card.className = "card";
            card.innerHTML = `
                <h3>${blog.title}</h3>
                <p>${blog.content}</p>
            `;
            postsContainer.appendChild(card);
        });
    }

    function renderTodos(todos) {
        todosContainer.innerHTML = "";
        indianTasks.forEach((task, index) => {
            const card = document.createElement("div");
            card.className = "card";
            card.innerHTML = `
                <h3>${task}</h3>
                <div class="todo-status ${todos[index].completed ? "completed" : "pending"}">
                    ${todos[index].completed ? "Completed" : "Pending"}
                </div>
            `;
            todosContainer.appendChild(card);
        });
    }

    async function loadPosts() {
        showBlogOnly();
        const posts = await fetchData(POSTS_URL);
        if (posts) renderPosts();
    }

    async function loadTodos() {
        showTodoOnly();
        const todos = await fetchData(TODOS_URL);
        if (todos) renderTodos(todos);
    }

    function init() {
        document.getElementById("loadPostsBtn")
            .addEventListener("click", loadPosts);

        document.getElementById("loadTodosBtn")
            .addEventListener("click", loadTodos);
    }

    return {
        init
    };

})();

document.addEventListener("DOMContentLoaded", DashboardApp.init);
