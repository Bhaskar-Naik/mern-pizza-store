import React, { Component } from "react";

class AuthorInfo extends Component {

  componentDidMount() {
    console.log("Author Loaded:", this.props.author.name);
  }

  render() {
    const { author } = this.props;

    return (
      <div className="mt-3 p-3 border rounded bg-light">
        <h6>About the Author</h6>
        <p><strong>Name:</strong> {author.name}</p>
        <p>{author.bio}</p>

        <h6>Top 3 Books:</h6>
        <ul>
          {author.topBooks.map((book, index) => (
            <li key={index}>{book}</li>
          ))}
        </ul>
      </div>
    );
  }
}

export default AuthorInfo;