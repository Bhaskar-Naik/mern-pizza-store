import React, { useState } from "react";
import PropTypes from "prop-types";
import AuthorInfo from "./AuthorInfo";

const BookCard = ({ book, viewType }) => {
  const [showAuthor, setShowAuthor] = useState(false);

  return (
    <div
      className={`card shadow-sm mb-3 ${viewType === "list" ? "d-flex flex-row" : ""}`}
      style={{ cursor: "pointer" }}
      onClick={() => setShowAuthor(!showAuthor)}
    >
      <img
        src={book.image}
        alt={book.title}
        className="card-img-top bg-light"
        style={
          viewType === "list"
            ? {
                width: "200px",
                height: "250px",
                objectFit: "contain",
              }
            : {
                height: "300px",
                objectFit: "contain",
              }
        }
      />

      <div className="card-body">
        <h5>{book.title}</h5>
        <p>
          <strong>Author:</strong> {book.author.name}
        </p>
        <p>
          <strong>Price:</strong> ${book.price}
        </p>

        {showAuthor && <AuthorInfo author={book.author} />}
      </div>
    </div>
  );
};

BookCard.propTypes = {
  viewType: PropTypes.string.isRequired,
  book: PropTypes.shape({
    title: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    image: PropTypes.string.isRequired,
    author: PropTypes.shape({
      name: PropTypes.string.isRequired,
      bio: PropTypes.string.isRequired,
      topBooks: PropTypes.array.isRequired,
    }).isRequired,
  }).isRequired,
};

export default BookCard;
