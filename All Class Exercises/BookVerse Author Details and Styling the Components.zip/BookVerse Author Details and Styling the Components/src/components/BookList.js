import React, { useState, useRef } from "react";
import BookCard from "./BookCard";

const BookList = () => {

  const [searchTerm, setSearchTerm] = useState("");
  const [viewType, setViewType] = useState("grid");
  const searchRef = useRef();

  const books = [
    {
      title: "Ikigai",
      price: 998.9,
      image: "https://m.media-amazon.com/images/I/81l3rZK4lnL._SY425_.jpg",
      author: {
        name: "Héctor García",
        bio: "Spanish author and expert in Japanese culture.",
        topBooks: ["Ikigai", "A Geek in Japan", "Ichigo Ichie"]
      }
    },
    {
      title: "The Power of Subconscious Mind",
      price: 8.99,
      image: "https://m.media-amazon.com/images/I/81ZPvRTVBwL._AC_UF1000,1000_QL80_.jpg",
      author: {
        name: "Dr. Joseph Murphy",
        bio: "Pioneer of subconscious mind philosophy.",
        topBooks: [
          "Power of Subconscious Mind",
          "Believe in Yourself",
          "Miracles of Your Mind"
        ]
      }
    },
    {
      title: "The Missile Man of India",
      price: 100.89,
      image: "https://m.media-amazon.com/images/I/81+Vf3lmPJL._UF1000,1000_QL80_.jpg",
      author: {
        name: "Dr. A.P.J. Abdul Kalam",
        bio: "Former President of India and aerospace scientist.",
        topBooks: [
          "Wings of Fire",
          "Ignited Minds",
          "India 2020"
        ]
      }
    }
  ];

  const filteredBooks = books.filter(book =>
    book.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const focusSearch = () => {
    searchRef.current.focus();
  };

  return (
    <div className="container mt-4">

      <h2 className="mb-4">BookVerse</h2>

      <div className="d-flex justify-content-between mb-4">

        <input
          ref={searchRef}
          type="text"
          className="form-control w-25"
          placeholder="Search books..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        <div>
          <button
            className="btn btn-outline-primary me-2"
            onClick={() => setViewType("grid")}
          >
            Grid
          </button>

          <button
            className="btn btn-outline-secondary"
            onClick={() => setViewType("list")}
          >
            List
          </button>

          <button
            className="btn btn-primary ms-3"
            onClick={focusSearch}
          >
            Focus Search
          </button>
        </div>

      </div>

      <div className={viewType === "grid" ? "row" : ""}>
        {filteredBooks.map((book, index) => (
          <div
            key={index}
            className={viewType === "grid" ? "col-md-4 mb-4" : ""}
          >
            <BookCard book={book} viewType={viewType} />
          </div>
        ))}
      </div>

    </div>
  );
};

export default BookList;