import { useNavigate, Link } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function Login() {

  const navigate = useNavigate();
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const username = e.target.username.value.trim();
    const password = e.target.password.value.trim();

    try {
      const response = await axios.get("http://localhost:3001/users");

      const user = response.data.find(
        (u) =>
          u.username === username &&
          u.password === password
      );

      if (user) {
        localStorage.setItem("userLoggedIn", "true");
        navigate("/home");
      } else {
        setError("Invalid credentials");
      }

    } catch (err) {
      setError("Server error");
    }
  };

  return (
    <div className="container mt-5">
      <h3>Login</h3>

      <form onSubmit={handleSubmit} className="card p-4">
        <input
          name="username"
          placeholder="Username"
          className="form-control mb-3"
          required
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          className="form-control mb-3"
          required
        />

        {error && <div className="text-danger mb-2">{error}</div>}

        <button className="btn btn-primary">
          Login
        </button>
      </form>

      <Link to="/register">New user? Register</Link>
    </div>
  );
}

export default Login;