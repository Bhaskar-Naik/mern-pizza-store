import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import AuthorInfo from "../components/AuthorInfo";

function BookDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:3001/books/${id}`)
      .then(res => setBook(res.data));
  }, []);

  if (!book) return null;

  return (
    <div className="container mt-4">
      <h3>{book.title}</h3>
      <img src={book.image} style={{height:"200px"}} />
      <p>Author: {book.author}</p>
      <p>Price: ₹{book.price}</p>

      <AuthorInfo book={book} />

      <button
        className="btn btn-secondary mt-3"
        onClick={() => navigate("/home")}
      >
        Back
      </button>
    </div>
  );
}

export default BookDetails;