import { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import BookCard from "../components/BookCard";
import Navbar from "../components/Navbar";

function Home() {

  const [books, setBooks] = useState([]);
  const navigate = useNavigate();

  const fetchBooks = () => {
    axios.get("http://localhost:3001/books")
      .then(res => setBooks(res.data));
  };

  useEffect(() => {
    if (localStorage.getItem("userLoggedIn") !== "true") {
      navigate("/");
    }
    fetchBooks();
  }, []);

  return (
    <>
      <Navbar />

      <div className="container mt-4">
        <h4>Home - BookVerse</h4>

        <div className="row mt-4">
          {books.map(book => (
            <BookCard
              key={book.id}
              book={book}
              refresh={fetchBooks}
            />
          ))}
        </div>
      </div>
    </>
  );
}

export default Home;