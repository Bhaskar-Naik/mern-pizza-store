import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function Register() {

  const navigate = useNavigate();
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const username = e.target.username.value;
    const password = e.target.password.value;

    if (!username || !password) {
      setError("All fields required");
      return;
    }

    await axios.post("http://localhost:3001/users", {
      username,
      password
    });

    navigate("/");
  };

  return (
    <div className="container mt-5">
      <h3>Register</h3>

      <form onSubmit={handleSubmit} className="card p-4">
        <input name="username" className="form-control mb-3" placeholder="Username" />
        <input name="password" type="password" className="form-control mb-3" placeholder="Password" />
        {error && <div className="text-danger">{error}</div>}
        <button className="btn btn-primary">Register</button>
      </form>
    </div>
  );
}

export default Register;