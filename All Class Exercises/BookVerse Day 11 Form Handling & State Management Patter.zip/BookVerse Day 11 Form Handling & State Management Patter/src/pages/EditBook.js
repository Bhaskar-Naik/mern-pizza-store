import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

function EditBook() {

  const { id } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:3001/books/${id}`)
      .then(res => setBook(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();

    await axios.put(
      `http://localhost:3001/books/${id}`,
      book
    );

    navigate("/dashboard");
  };

  return (
    <div className="container mt-4">
      <h3>Edit Book</h3>

      <form onSubmit={handleSubmit} className="card p-4">

        <input className="form-control mb-2"
          value={book.title || ""}
          onChange={e=>setBook({...book,title:e.target.value})}
        />

        <input className="form-control mb-2"
          value={book.author || ""}
          onChange={e=>setBook({...book,author:e.target.value})}
        />

        <input className="form-control mb-2"
          value={book.price || ""}
          onChange={e=>setBook({...book,price:e.target.value})}
        />

        <input className="form-control mb-2"
          value={book.image || ""}
          onChange={e=>setBook({...book,image:e.target.value})}
        />

        <textarea className="form-control mb-2"
          value={book.aboutAuthor || ""}
          onChange={e=>setBook({...book,aboutAuthor:e.target.value})}
        />

        <input className="form-control mb-2"
          value={book.topBooks?.[0] || ""}
          onChange={e=>{
            const updated = [...(book.topBooks || [])];
            updated[0] = e.target.value;
            setBook({...book,topBooks:updated});
          }}
        />

        <input className="form-control mb-2"
          value={book.topBooks?.[1] || ""}
          onChange={e=>{
            const updated = [...(book.topBooks || [])];
            updated[1] = e.target.value;
            setBook({...book,topBooks:updated});
          }}
        />

        <input className="form-control mb-3"
          value={book.topBooks?.[2] || ""}
          onChange={e=>{
            const updated = [...(book.topBooks || [])];
            updated[2] = e.target.value;
            setBook({...book,topBooks:updated});
          }}
        />

        <button className="btn btn-primary">Update</button>

      </form>
    </div>
  );
}

export default EditBook;