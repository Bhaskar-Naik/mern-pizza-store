import { useNavigate } from "react-router-dom";
import axios from "axios";

function AddBook() {

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const book = {
      title: e.target.title.value,
      author: e.target.author.value,
      price: e.target.price.value,
      image: e.target.image.value,
      aboutAuthor: e.target.aboutAuthor.value,
      topBooks: [
        e.target.book1.value,
        e.target.book2.value,
        e.target.book3.value
      ]
    };

    await axios.post("http://localhost:3001/books", book);
    navigate("/dashboard");
  };

  return (
    <div className="container mt-4">
      <h3>Add Book</h3>

      <form onSubmit={handleSubmit} className="card p-4">

        <input name="title" placeholder="Title" className="form-control mb-3"/>
        <input name="author" placeholder="Author" className="form-control mb-3"/>
        <input name="price" placeholder="Price" className="form-control mb-3"/>
        <input name="image" placeholder="Image URL" className="form-control mb-3"/>

        <textarea name="aboutAuthor" placeholder="About Author"
          className="form-control mb-3"/>

        <input name="book1" placeholder="Top Book 1" className="form-control mb-2"/>
        <input name="book2" placeholder="Top Book 2" className="form-control mb-2"/>
        <input name="book3" placeholder="Top Book 3" className="form-control mb-3"/>

        <button className="btn btn-primary">Submit</button>

      </form>
    </div>
  );
}

export default AddBook;