import { useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

function AdminLogin() {

  const navigate = useNavigate();
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const username = e.target.username.value;
    const password = e.target.password.value;

    const res = await axios.get(
      `http://localhost:3001/admins?username=${username}&password=${password}`
    );

    if (res.data.length > 0) {
      localStorage.setItem("adminLoggedIn", "true");
      navigate("/admin-dashboard");
    } else {
      setError("Invalid admin credentials");
    }
  };

  return (
    <div className="container mt-5">
      <h3>Admin Login</h3>

      <form onSubmit={handleSubmit} className="card p-4">
        <input name="username" className="form-control mb-3" />
        <input name="password" type="password" className="form-control mb-3" />
        {error && <div className="text-danger">{error}</div>}
        <button className="btn btn-danger">Login</button>
      </form>
    </div>
  );
}

export default AdminLogin;