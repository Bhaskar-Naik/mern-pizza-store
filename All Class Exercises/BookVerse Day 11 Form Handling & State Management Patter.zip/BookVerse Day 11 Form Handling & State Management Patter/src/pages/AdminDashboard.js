import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";

function AdminDashboard() {

  const navigate = useNavigate();

  return (
    <>
      <Navbar />

      <div className="container mt-5 text-center">
        <h3>Admin Dashboard</h3>

        <button
          className="btn btn-success m-2"
          onClick={() => navigate("/add")}
        >
          Add Book
        </button>

        <button
          className="btn btn-warning m-2"
          onClick={() => navigate("/edit-books")}
        >
          Edit / Remove Books
        </button>
      </div>
    </>
  );
}

export default AdminDashboard;