import dispatcher from "./dispatcher";

let books = [];
let listeners = [];

dispatcher.register((action) => {
  switch (action.type) {

    case "SET_BOOKS":
      books = action.payload;
      notify();
      break;

    case "ADD_BOOK":
      books = [...books, action.payload];
      notify();
      break;

    default:
      break;
  }
});

function notify() {
  listeners.forEach((listener) => listener());
}

const bookStore = {

  getBooks: () => books,

  subscribe: (listener) => {
    listeners.push(listener);
  }

};

export default bookStore;