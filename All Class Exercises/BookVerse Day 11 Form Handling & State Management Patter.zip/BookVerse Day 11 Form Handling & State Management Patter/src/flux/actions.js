import dispatcher from "./dispatcher";

export const addBook = (book) => {
  dispatcher.dispatch({
    type: "ADD_BOOK",
    payload: book
  });
};

export const setBooks = (books) => {
  dispatcher.dispatch({
    type: "SET_BOOKS",
    payload: books
  });
};