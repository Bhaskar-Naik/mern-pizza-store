function LoadingSpinner() {
  return (
    <div className="d-flex justify-content-center mt-5">
      <div className="spinner-border text-primary" role="status"></div>
    </div>
  );
}

export default LoadingSpinner;