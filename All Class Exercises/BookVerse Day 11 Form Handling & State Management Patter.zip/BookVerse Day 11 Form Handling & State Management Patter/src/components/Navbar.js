import { useNavigate } from "react-router-dom";

function Navbar() {

  const navigate = useNavigate();
  const isAdmin = localStorage.getItem("adminLoggedIn") === "true";

  const handleLogout = () => {
    localStorage.removeItem("adminLoggedIn");
    navigate("/home");
  };

  return (
    <nav className="navbar navbar-dark bg-dark px-4">
      <span className="navbar-brand text-white">
        BookVerse
      </span>

      <div>
        {!isAdmin && (
          <button
            className="btn btn-outline-light btn-sm"
            onClick={() => navigate("/admin-login")}
          >
            Admin Login
          </button>
        )}

        {isAdmin && (
          <button
            className="btn btn-danger btn-sm"
            onClick={handleLogout}
          >
            Admin Logout
          </button>
        )}
      </div>
    </nav>
  );
}

export default Navbar;