import { Link } from "react-router-dom";
import axios from "axios";

function BookCard({ book, refresh }) {

  const isAdmin = localStorage.getItem("adminLoggedIn") === "true";

  const handleDelete = async () => {
    await axios.delete(`http://localhost:3001/books/${book.id}`);
    refresh();
  };

  const buttonStyle = {
    backgroundColor: "#000",
    color: "#FFDAB9",   
    border: "none",
    padding: "6px 14px",
    fontSize: "14px"
  };

  return (
    <div className="col-lg-3 col-md-6 mb-4">
      <div className="card shadow-sm h-100 d-flex flex-column">

        <div
          className="d-flex justify-content-center align-items-center"
          style={{ height: "200px", backgroundColor: "#f8f9fa" }}
        >
          <img
            src={book.image}
            alt={book.title}
            style={{
              maxHeight: "180px",
              maxWidth: "100%",
              objectFit: "contain"
            }}
          />
        </div>

        <div className="card-body text-center d-flex flex-column">

          <h6 style={{ minHeight: "48px" }}>
            {book.title}
          </h6>

          <p className="text-muted mb-1">
            {book.author}
          </p>

          <strong className="mb-3">
            ₹ {book.price}
          </strong>

          <div className="mt-auto d-flex justify-content-center gap-3 flex-wrap">

            <Link
              to={`/book/${book.id}`}
              className="btn"
              style={buttonStyle}
            >
              View
            </Link>

            {isAdmin && (
              <>
                <Link
                  to={`/edit/${book.id}`}
                  className="btn"
                  style={buttonStyle}
                >
                  Edit
                </Link>

                <button
                  onClick={handleDelete}
                  className="btn"
                  style={buttonStyle}
                >
                  Delete
                </button>
              </>
            )}

          </div>

        </div>
      </div>
    </div>
  );
}

export default BookCard;