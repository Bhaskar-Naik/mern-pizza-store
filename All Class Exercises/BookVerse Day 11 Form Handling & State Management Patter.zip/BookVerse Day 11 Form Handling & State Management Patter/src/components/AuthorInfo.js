import React from "react";

function AuthorInfo({ book }) {

  if (!book) return null;

  return (
    <div className="card p-3 mt-3">
      <h5>About the Author</h5>
      <p>{book.aboutAuthor}</p>

      <h6>Top 3 Books</h6>
      <ul>
        {book.topBooks?.map((b, i) => (
          <li key={i}>{b}</li>
        ))}
      </ul>
    </div>
  );
}

export default AuthorInfo;