import LoadingSpinner from "./LoadingSpinner";

const withLoader = (WrappedComponent) => {
  return function ({ isLoading, ...props }) {
    if (isLoading) return <LoadingSpinner />;
    return <WrappedComponent {...props} />;
  };
};

export default withLoader;