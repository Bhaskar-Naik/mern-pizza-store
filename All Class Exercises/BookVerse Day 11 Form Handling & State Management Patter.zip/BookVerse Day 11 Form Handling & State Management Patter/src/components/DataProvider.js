import { useState, useEffect } from "react";
import axios from "axios";

function DataProvider({ url, children }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(url)
      .then(res => {
        setData(res.data);
        setLoading(false);
      });
  }, [url]);

  return children({ data, loading });
}

export default DataProvider;